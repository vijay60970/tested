<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Item\\Providers\\ItemServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Item\\Providers\\ItemServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);