<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\IteM\\Providers\\IteMServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\IteM\\Providers\\IteMServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);