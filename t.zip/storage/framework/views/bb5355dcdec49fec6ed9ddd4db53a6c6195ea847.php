<?php $__env->startSection('title', 'Customer ManageMent'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
   <!-- Basic Layout -->
  <div class="col-xxl">
    <div class="card mb-4">
      <div class="card-header d-flex align-items-center justify-content-between">
        <h5 class="mb-0">Customer Management</h5> <small class="text-muted float-end">Add Customer</small>
      </div>
      <div class="card-body">
        <form>
          <div class="row mb-3">
            <label class="col-sm-2 col-form-label" for="basic-default-name">Customer Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="basic-default-name" placeholder="Customer Name" />
            </div>
          </div>
          <div class="row mb-3">
            <label class="col-sm-2 col-form-label" for="basic-default-company">Mobile Number</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="basic-default-company" placeholder="Mobile Number" />
            </div>
          </div>
          <div class="row mb-3">
            <label class="col-sm-2 col-form-label" for="basic-default-email">Address</label>
            <div class="col-sm-10">
              <div class="input-group input-group-merge">
              <textarea id="basic-default-message" class="form-control" placeholder="Address" aria-label="Hi, Do you have a moment to talk Joe?" aria-describedby="basic-icon-default-message2"></textarea>
              </div> 
            </div>
          </div> 
          <div class="row justify-content-end">
            <div class="col-sm-10">
              <button type="submit" class="btn btn-primary">Send</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\sneat\Modules/Customers\Resources/views/index.blade.php ENDPATH**/ ?>