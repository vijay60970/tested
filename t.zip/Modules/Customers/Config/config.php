<?php

return [
    'name' => 'Customers'
];
